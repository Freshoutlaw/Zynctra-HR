package com.zynctra.ats.entity;

import com.zynctra.common.entity.BaseEntity;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Entity
@Table(name = "candidates", indexes = {
    @Index(name = "idx_candidates_job_id", columnList = "job_id"),
    @Index(name = "idx_candidates_stage", columnList = "stage"),
    @Index(name = "idx_candidates_email", columnList = "email")
})
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Candidate extends BaseEntity {
    @Column(name = "email", nullable = false)
    private String email;

    @Column(name = "first_name", nullable = false)
    private String firstName;

    @Column(name = "last_name", nullable = false)
    private String lastName;

    @Column(name = "phone_number")
    private String phoneNumber;

    @Column(name = "job_id", nullable = false)
    private String jobId;

    @Column(name = "stage")
    private String stage; // APPLIED, SCREENING, INTERVIEW, OFFER, HIRED, REJECTED

    @Column(name = "resume_url")
    private String resumeUrl;

    @Column(name = "score", precision = 5, scale = 2)
    private Double score;

    @Column(name = "applied_date")
    private LocalDate appliedDate;

    @Column(name = "source")
    private String source; // LINKEDIN, WEBSITE, REFERRAL, etc.
}
